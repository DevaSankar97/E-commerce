import { Component } from '@angular/core';

@Component({
  selector: 'app-boost',
  imports: [],
  templateUrl: './boost.component.html',
  styleUrl: './boost.component.css'
})
export class BoostComponent {

}
