import { Component } from '@angular/core';

@Component({
  selector: 'app-invite',
  imports: [],
  templateUrl: './invite.component.html',
  styleUrl: './invite.component.css'
})
export class InviteComponent {

}
