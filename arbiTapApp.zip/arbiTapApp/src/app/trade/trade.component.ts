import { Component } from '@angular/core';

@Component({
  selector: 'app-trade',
  imports: [],
  templateUrl: './trade.component.html',
  styleUrl: './trade.component.css'
})
export class TradeComponent {

}
