import { Component } from '@angular/core';

@Component({
  selector: 'app-arbi-tap',
  imports: [],
  templateUrl: './arbi-tap.component.html',
  styleUrl: './arbi-tap.component.css'
})
export class ArbiTapComponent {

}
